<?php
require __DIR__.'/../config.php'; require_admin();
$songs=$pdo->query("SELECT * FROM songs ORDER BY created_at DESC")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard</title><link rel="stylesheet" href="../assets/style.css"></head>
<body><main class="wrap"><div class="panel"><h1>Private Song Dashboard</h1>
<div class="nav"><a class="button" href="song_new.php">+ New Song</a><a class="button" href="customer_new.php">+ Customer Password</a><a class="button" href="customers.php">Customer Access</a><a class="button" href="qr.php">ONE QR CODE</a><a class="button" href="logout.php">Logout</a></div>
<table><tr><th>Song</th><th>Artist</th><th>Status</th></tr>
<?php foreach($songs as $s): ?><tr><td><?=e($s['title'])?></td><td><?=e($s['artist'])?></td><td><?=((int)$s['is_active']?'Active':'Disabled')?></td></tr><?php endforeach; ?>
<?php if(!$songs):?><tr><td colspan="3" class="muted">No songs uploaded yet.</td></tr><?php endif;?>
</table></div></main></body></html>
